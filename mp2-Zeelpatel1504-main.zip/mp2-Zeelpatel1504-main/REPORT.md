# MP Report

## Team

- Name(s): Patel Zeel Rakshitkumar
- AID(s): A20556822

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The app builds without error
- [x] I tested the app in at least one of the following platforms (check all that apply):
  - [ ] iOS simulator / MacOS
  - [ ] Android emulator
  - [x] Google Chrome
  - [x] Windows Edge
- [x] The page displays correctly in a window of at least 1024x768 pixels
- [x] The layout contains at least 4 distinct sections
- [x] The layout makes use of the required widgets
- [x] The page uses at least three images
- [x] The page utilizes at least one nested row/column widget
- [x] The implementation uses a data model class to represent user information

## Summary and Reflection

Balanced Layout: I organized the skills section into two clean rows, ensuring there were no unnecessary gaps. This helped maintain a visually appealing and well-spaced layout.with color combination
Using the Wrap Widget: I used the Wrap widget to arrange the skills flexibly. This allowed the layout to adjust dynamically without creating clutter or leaving empty spaces.
I faced little bit difficulty in arranging my skills i wanted to do it in row formate but somehow i am not able to do that but i figure it out i still can improve it 



I really enjoyed working on the layout, especially when it came to organizing the skills section in a neat and visually appealing way. Flutter’s structure made it easy to work with, and I loved how smoothly everything came together once the elements were properly aligned. However, at first, I struggled a bit with figuring out how to manage the layout, especially with spacing and alignment. It took some trial and error to get things right.

I wish I had known more about Flutter’s advanced layout techniques before starting. It would have made the whole design process smoother, especially when it came to managing the spacing between elements and creating a more balanced structure.
