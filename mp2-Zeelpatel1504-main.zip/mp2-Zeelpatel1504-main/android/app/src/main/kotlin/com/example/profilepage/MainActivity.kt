package com.example.profilepage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
